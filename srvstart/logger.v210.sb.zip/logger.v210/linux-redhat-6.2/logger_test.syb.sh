#!/bin/sh
export SYBASE=/opt/sybase
export LANG=default

./logger_test.syb

