/*
** little hack to test "logger" DLL
*/

/* platform? */
#if		defined(WIN32)
#define	LOGGER_PLATFORM_IS_WIN32	1
#define	LOGGER_PLATFORM_IS_LINUX	0
#elif	defined(__linux__)
#define	LOGGER_PLATFORM_IS_WIN32	0
#define	LOGGER_PLATFORM_IS_LINUX	1
#else
#error	BUILD FAILURE - the Logger only runs on Win32 and Linux
#endif

#include <logger.linux.h>
#include <ctype.h>
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* #include <conio.h> */
#include <sys/types.h>
#include <sys/stat.h>
#ifdef	LOGGER_BUILD_WITH_SYBASE_HEADERS
#include <cspublic.h>
#include <ctpublic.h>
#include <ospublic.h>
#endif	// LOGGER_BUILD_WITH_SYBASE_HEADERS

#if	LOGGER_PLATFORM_IS_WIN32
#pragma warning(disable:4142)	// benign redefinition of type
#include <windows.h>
#endif

#ifndef	BOOL
#define	BOOL int
#endif
#ifndef	TRUE
#define	TRUE 1
#endif
#ifndef	FALSE
#define	FALSE 0
#endif

#define	EOS			'\0'
#define	ASTERISK	'*'
#define	BSL			'\\'
#define	COMMENT		'#'
#define	RETURN		13
#define	NEWLINE		'\n'
#define	QUESTION	'?'
#define	QUOTE		'"'
#define	SPACE		' '
#define	FLAG_NONE	0
#define	FLAG_CLEAR	1
#define	FLAG_LOWER	2
#define	FLAG_UPPER	4
#define	INSERT_LINEFEED		40

#if	LOGGER_PLATFORM_IS_WIN32
#define ANSI_LOGFILE	"C:\\TEMP\\LOGGER_TEST.ANSI.LOG"
#define WIN32_LOGFILE	"C:\\TEMP\\LOGGER_TEST.WIN32.LOG"
#define	SYBASE_LOG_FILE	"C:\\TEMP\\LOGGER_TEST.SYBASE.LOG"
#else
#define ANSI_LOGFILE	"/tmp/logger_test.ansi.log"
#define WIN32_LOGFILE	"/tmp/logger_test.win32.log"
#define	SYBASE_LOG_FILE	"/tmp/logger_test.sybase.log"
#endif

#ifdef	LOGGER_BUILD_WITH_SYBASE_HEADERS

#define	DFLT_OPEN_SERVER	"LOGGER_TEST_SRV"

BOOL sybinit(char OpenServer[]);
CS_RETCODE CS_PUBLIC logger_test_cs_callback( CS_CONTEXT *ContextPtr,
						CS_CLIENTMSG *MsgPtr);
CS_RETCODE CS_PUBLIC logger_test_ct_callback(CS_CONTEXT *ContextPtr,
						CS_CONNECTION *ConnectionPtr,CS_CLIENTMSG *MsgPtr);
CS_RETCODE CS_PUBLIC logger_test_srv_callback(CS_CONTEXT *ContextPtr,
						CS_CONNECTION *ConnectionPtr,CS_SERVERMSG *MsgPtr);

#endif	// LOGGER_BUILD_WITH_SYBASE_HEADERS

char *Gdest_help[] = {
		"N   - none",
		"F   - format only",
		"AS  - ANSI stdout",
		"AFN - ANSI filename",
		"AFP - ANSI file pointer",

#if	LOGGER_PLATFORM_IS_WIN32
		"WS  - Win32 stdout",
		"WFN - Win32 filename",
		"WFH - Win32 file handle",
		"E   - Event Log",
#endif	// LOGGER_PLATFORM_IS_WIN32

#ifdef	LOGGER_BUILD_WITH_SYBASE_HEADERS
		"S   - Sybase Open Server Log",
#endif	// LOGGER_BUILD_WITH_SYBASE_HEADERS

#if	LOGGER_PLATFORM_IS_LINUX
		"Y   - Unix syslog",
#endif	// LOGGER_PLATFORM_IS_LINUX

		"X   - EXIT", };

#ifdef	LOGGER_BUILD_WITH_SYBASE_HEADERS
CS_CONTEXT *Gctx_ptr;
#endif	// LOGGER_BUILD_WITH_SYBASE_HEADERS

void util_readline
(
	char      *prompt_ptr,
	char      *default_reply_ptr,
	char      *domain_ptr,
	char      *helptext_ptr[],
	short int  helplines,
	short int  linelength,
	char      *line_ptr,
	int        flags
);

int main(int argc, char *argv[])
{
	char      Reply[1000];
	int       Error;
	short int LoggerId = LOGGER_NO_UNUSED_LOGGER;
	int       MsgClass;
	int       MsgSeverity;
	int       Destination;
	char      FileName[1000];
	char      BigBuffer[LOGGER_BUFFERSIZE];
	FILE     *ANSIFilePtr;
#if	LOGGER_PLATFORM_IS_WIN32
	HANDLE    lpConsole;
	HANDLE    lpLogfile;
	char      Computer[100];
#endif
	void     *DestDetails1;
	char      ThreadId[30];
	char      SourceFile[1000];
	char      SourceLine[30];
	char      FuncName[100];
	char      MsgText[1000];
	char      ErrorMsgText[1000];
#ifdef	LOGGER_BUILD_WITH_SYBASE_HEADERS
	char      OpenServer[100];
	BOOL      SybinitNotRanYet = CS_TRUE;
#endif	// LOGGER_BUILD_WITH_SYBASE_HEADERS
	int       FilterMsgClass;
	int       FilterMsgSeverity;
	int       FilterThreadId;
	char      FilterSourceFile[1000];
	char      FilterFuncName[100];
	char      ThreadIdChar[50];
	char      ClassesChar[50];

	printf("LOGGER TEST\n");

	ANSIFilePtr=fopen(ANSI_LOGFILE,"a");

#if	LOGGER_PLATFORM_IS_WIN32
	lpLogfile=CreateFile(WIN32_LOGFILE,GENERIC_WRITE,
								FILE_SHARE_READ|FILE_SHARE_WRITE,
								NULL,OPEN_ALWAYS,FILE_FLAG_WRITE_THROUGH,NULL);
	SetFilePointer(lpLogfile,0,NULL,FILE_END);
	lpConsole=GetStdHandle(STD_OUTPUT_HANDLE);
#endif	// LOGGER_PLATFORM_IS_WIN32

	while(TRUE)
	{

		printf("Current LoggerId = %d\n",(int)LoggerId);
		util_readline("Get Unused Logger?","Y","YN",NULL,0,sizeof(Reply),Reply,FLAG_UPPER);
		if(Reply[0] == 'Y')
		{
			LoggerId = LoggerGetUnusedLogger();
			if(LoggerId == LOGGER_NO_UNUSED_LOGGER)
			{
				printf("NO FREE LOGGER LEFT!\n"); goto TheEnd;
			}
			else
			{
				printf("New Logger Id = %d\n",(int)LoggerId);
			}
		}

		/* DESTINATION */
		while(1)
		{
			Destination = 9999;
			util_readline("destination type","AS","",Gdest_help,sizeof(Gdest_help)/sizeof(char*),
							sizeof(Reply),Reply,FLAG_UPPER);
			if(!strcmp(Reply,"X")) { goto TheEnd; }
			if(!strcmp(Reply,"N"))
			{
				printf(" (destination = none)\n");
				Destination=LOGGER_NONE; DestDetails1=NULL;
			}
			if(!strcmp(Reply,"F"))
			{
				printf(" (destination = format only)\n");
				Destination=LOGGER_FMTONLY; DestDetails1=(void*)BigBuffer;
			}
			if(!strcmp(Reply,"AS"))
			{
				printf(" (destination = ANSI stdout)\n");
				Destination=LOGGER_ANSI_STDOUT; DestDetails1=NULL;
			}
			if(!strcmp(Reply,"AFN"))
			{
				printf(" (destination = ANSI filename)\n");
				Destination=LOGGER_ANSI_FILENAME;
				strcpy(FileName,ANSI_LOGFILE);
				DestDetails1=(void*)FileName;
			}
			if(!strcmp(Reply,"AFP"))
			{
				printf(" (destination = ANSI file pointer)\n");
				Destination=LOGGER_ANSI_FILEPTR; 
				DestDetails1=(void*)ANSIFilePtr;
			}
#if	LOGGER_PLATFORM_IS_WIN32
			if(!strcmp(Reply,"WS"))
			{
				printf(" (destination = Win32 stdout)\n");
				Destination=LOGGER_WIN32_CONSOLE; DestDetails1=(void*)&lpConsole;
			}
			if(!strcmp(Reply,"WFN")) 
			{
				printf(" (destination = Win32 filename)\n");
				Destination=LOGGER_WIN32_FILENAME;
				strcpy(FileName,WIN32_LOGFILE);
				DestDetails1=(void*)FileName;
			}
			if(!strcmp(Reply,"WFH")) 
			{
				printf(" (destination = Win32 file handle)\n");
				Destination=LOGGER_WIN32_FILEHANDLE; 
				DestDetails1=(void*)&lpLogfile;
			}
			if(!strcmp(Reply,"E"))
			{
				printf(" (destination = Win32 event log)\n");
				Destination=LOGGER_WIN32_EVENTLOG;
				util_readline("computer","","",NULL,0,sizeof(Computer),Reply,FLAG_UPPER);
				strcpy(Computer,Reply);
				DestDetails1=(void*)Computer;
			}
#endif

#ifdef	LOGGER_BUILD_WITH_SYBASE_HEADERS

			if(!strcmp(Reply,"S"))
			{
				printf(" (destination = Sybase Open Server log)\n");
				util_readline("Open Server",DFLT_OPEN_SERVER,"",NULL,0,sizeof(OpenServer),Reply,FLAG_UPPER);
				strcpy(OpenServer,Reply);
				Destination=LOGGER_SYBASE_SRVLOG;
				DestDetails1=NULL;
				if(SybinitNotRanYet)
				{
					if(sybinit(OpenServer)==0)
					{
						SybinitNotRanYet=CS_FALSE;
					}
					else
					{
						printf("sybinit(OpenServer[]) failed\n");
						goto TheEnd;
					}
				}
			}
#endif	// LOGGER_BUILD_WITH_SYBASE_HEADERS

#if	LOGGER_PLATFORM_IS_LINUX
			if(!strcmp(Reply,"Y"))
			{
				printf(" (destination = Unix syslog)\n");
				Destination=LOGGER_UNIX_SYSLOG; DestDetails1=NULL;
			}
#endif	// LOGGER_PLATFORM_IS_LINUX
			if(Destination!=9999) { goto GotDestination; }
		}

GotDestination:

		printf("Configuring Logger %d...\n",(int)LoggerId); fflush(stdout);
		if(LoggerConfigure(LoggerId,"MYHOST","LOGGER_TEST",Destination,DestDetails1,NULL,&Error,ErrorMsgText)==0)
		{
			printf("Failed, error=%d '%s'\n",Error,ErrorMsgText);
			goto TheEnd;
		}
		printf("OK\n");

		// filter?
		util_readline("Filter for this destination?","N","YN",NULL,0,sizeof(Reply),Reply,FLAG_UPPER);
		if(Reply[0] == 'N')
		{
			LOGGER_FILTER_ALL(LoggerId)
		}
		else
		{
			util_readline("All, Debug only, Error, Info/error, Special?","A","ADEIS",NULL,0,sizeof(Reply),Reply,FLAG_UPPER);
			printf("Setting Filter \n");

			switch(Reply[0])
			{

			case 'A': LOGGER_FILTER_ALL(LoggerId) break;
			case 'D': LOGGER_FILTER_DEBUG_ONLY(LoggerId) break;
			case 'E': LOGGER_FILTER_ERROR_ONLY(LoggerId) break;
			case 'I': LOGGER_FILTER_ERROR_INFO(LoggerId) break;
			default:

				sprintf(ClassesChar,"%d",LOGGER_ALL_CLASSES_FILTER);
				util_readline("Message Classes?",ClassesChar,"",NULL,0,sizeof(Reply),Reply,0);
				FilterMsgClass=atoi(Reply);

				util_readline("Message Severity?","-1","",NULL,0,sizeof(Reply),Reply,0);
				FilterMsgSeverity=atoi(Reply);

#if	LOGGER_PLATFORM_IS_WIN32
				sprintf(ThreadIdChar,"%d",GetCurrentThreadId());
#else
				sprintf(ThreadIdChar,"%d",0);
#endif
				util_readline("Thread Id?",ThreadIdChar,"",NULL,0,sizeof(Reply),Reply,0);
				FilterThreadId=atoi(Reply);

				
				util_readline("Source File (- for none)?",__FILE__,"",NULL,0,sizeof(FilterSourceFile),FilterSourceFile,0);
				if(!strcmp(FilterSourceFile,"-")) { FilterSourceFile[0]='\0'; }

				util_readline("Function?","","",NULL,0,sizeof(FilterFuncName),FilterFuncName,0);

				LoggerSetFilter(LoggerId,0,FilterMsgClass,FilterMsgSeverity,FilterThreadId,FilterSourceFile,FilterFuncName);
				break;
			}

			printf("OK\n");

		}

		while(1)
		{
			/* CLASS */
			util_readline("class (X to finish)","W","BIWEDSFZX",NULL,0,sizeof(Reply),Reply,FLAG_UPPER);
			switch(Reply[0])
			{
				case 'B': MsgClass=LOGGER_BARE;  break;
				case 'I': MsgClass=LOGGER_INFO;  break;
				case 'W': MsgClass=LOGGER_WARN;  break;
				case 'E': MsgClass=LOGGER_ERROR; break;
				case 'D': MsgClass=LOGGER_DEBUG; break;
				case 'S': MsgClass=LOGGER_AUDIT_SUCCESS; break;
				case 'F': MsgClass=LOGGER_AUDIT_FAILURE; break;
				case 'Z': MsgClass=999; break;
				case 'X': goto EndLoop;
				default: break;
			}

			/* SEVERITY */
			util_readline("severity integer","0","",NULL,0,sizeof(Reply),Reply,FLAG_NONE);
			MsgSeverity=atoi(Reply);

			/* THREAD */
			util_readline("thread (-1 none, -2 NT)","-2","",NULL,0,sizeof(ThreadId),ThreadId,FLAG_NONE);

			/* SOURCE FILE */
			util_readline("source file (- for none)",__FILE__,"",NULL,0,sizeof(SourceFile),SourceFile,FLAG_NONE);
			if(!strcmp(SourceFile,"-")) { SourceFile[0]='\0'; }

			/* SOURCE LINE */
			util_readline("source line","155","",NULL,0,sizeof(SourceLine),SourceLine,FLAG_NONE);

			/* FUNCTION */
			util_readline("function (- for none)","myfunc","",NULL,0,sizeof(FuncName),FuncName,FLAG_NONE);
			if(!strcmp(FuncName,"-")) { FuncName[0]='\0'; }

			/* MESSAGE TEXT */
			strcpy(MsgText,"Example LOGGER message with one string argument '%s'");

			printf(" ==> About to write message '%s'\n\n",MsgText);
			LoggerWriteMessage(MsgClass,MsgSeverity,atoi(ThreadId),SourceFile,
								atoi(SourceLine),FuncName,MsgText,"MY ARGUMENT");
			printf("\n ==> Wrote message '%s'\n",MsgText);

			if(Destination==LOGGER_FMTONLY)
			{
				printf("format only: string='%s'\n",BigBuffer);fflush(stdout);
			}
			printf("\n");
		}

EndLoop:;

	}

TheEnd:

	printf("Press any key ...\n");fflush(stdout);getchar();
	return 0;
}

/******************************************************************************
**
** FUNCTION    : util_readline
**
** DESCRIPTION : read a line of input from stdin, ignoring lines beginning with
**               a comment character #
**
** ARGUMENTS   : prompt_ptr         prompt text (displayed first)
**               default_reply_ptr  default reply ("" for none)
**               domain_ptr         string which lists all valid single-character
**                                   reponses ("" for no checking)
**               helptext_ptr       pointer to character array of help text (NULL
**                                   for no help)
**               helplines          number of elements in help text array
**               linelength         maximum characters to read in reply
**               line_ptr (OUTPUT)  buffer where reply will be stored (null-
**                                   terminated)
**               flags              I/O control, one or more of the following bit values:
**                                   FLAG_NONE	no special control
**                                   FLAG_CLEAR	entered text is not displayed
**                                   FLAG_LOWER	entered text is converted to lower-case
**                                   FLAG_UPPER	entered text is converted to upper-case
**
** RETURNS     : n/a
**
******************************************************************************/
void util_readline
(
	char      *prompt_ptr,
	char      *default_reply_ptr,
	char      *domain_ptr,
	char      *helptext_ptr[],
	short int  helplines,
	short int  linelength,
	char      *line_ptr,
	int        flags
)
{
	char *buffer_ptr = (char*)malloc(linelength*sizeof(char));
	char *get_ptr;
	int   get_char,char_count;
	char *in_ptr,*out_ptr;
	int   i;
	BOOL  last_char;

	while(1)
	{
		/* initialise pointers */
		in_ptr=buffer_ptr;
		out_ptr=line_ptr;

		/* display the prompt */
		if(helplines>0)
		{
			if(default_reply_ptr[0]==EOS) { printf("%s (? for help): ",prompt_ptr); }
			else { printf("%s (? for help) [%s]: ",prompt_ptr,default_reply_ptr); }
		}
		else
		{
			if(default_reply_ptr[0]==EOS) { printf("%s: ",prompt_ptr); }
			else { printf("%s [%s]: ",prompt_ptr,default_reply_ptr); }
		}

		/* print a newline if the default is very long */
		if(strlen(default_reply_ptr)>INSERT_LINEFEED) { printf("\n"); }

		/* read the reply */
		/* fgets(buffer_ptr,linelength,stdin); */
		fflush(stdout);
		get_ptr = buffer_ptr;
		char_count=0;
		while(1)
		{
			if((flags&FLAG_CLEAR)!=0)
			{
				/* get hidden text */
				get_char=getchar();printf("\b");
				last_char=(get_char==RETURN);
				if(last_char) { printf("\n"); fflush(stdout); }
			}
			else
			{
				/* get plain text */
				get_char=getc(stdin);
				last_char=(get_char==NEWLINE);
			}
			if(last_char) { (*get_ptr)=EOS; break; }
			if((flags&FLAG_LOWER)!=0) { get_char=tolower(get_char); }
			if((flags&FLAG_UPPER)!=0) { get_char=toupper(get_char); }
			(*get_ptr++)=(char)get_char;
			if((char_count++)>=linelength-1) { (*get_ptr)=EOS; break; }
		}

		/* is the first character a comment character? */
		while ((*in_ptr)==SPACE) { in_ptr++; }
		if((*in_ptr)==COMMENT) { continue; }

		/* is the first character a question mark? */
		if((*in_ptr)==QUESTION)
		{
			/* display help, if any */
			if(helplines==0)
			{
				printf("No help is available for this prompt.\n");
			}
			else
			{
				for(i=0;i<helplines;i++) { printf(i==0?" HELP: %s\n":" %s\n",helptext_ptr[i]); }
			}
			printf("\n"); continue;
		}

		/* copy the rest of the line into the output */
		while((*in_ptr)!=EOS)
		{
			if((*in_ptr)!=NEWLINE)
			{
				/* do not copy the newline character (if any) */
				(*out_ptr++)=(*in_ptr);
			}
			in_ptr++;
		}
		/* append a string termination character */
		(*out_ptr)=EOS;

		/* is the string empty? */
		if((*line_ptr)==EOS)
		{
			/* copy the default value into the reply */
			strcpy(line_ptr,default_reply_ptr);
		}

		/* check to make sure the reply is within the domain, if supplied */
		if((*domain_ptr)!=EOS)
		{
			if((strchr(domain_ptr,(*line_ptr))==NULL)||(strlen(line_ptr)!=1))
			{
				printf("Try again - reply must be one of [%s]\n",domain_ptr);
				continue;
			}
			else
			{
				/* reply is within domain */
				break;
			}
		}
		else
		{
			/* no domain supplied - exit the while loop */
			break;
		}
	}

	/* free the allocated buffer */
	free(buffer_ptr);
}

#ifdef	LOGGER_BUILD_WITH_SYBASE_HEADERS

/******************************************************************************
**
** FUNCTION    : sybinit
**
** DESCRIPTION : initialise Sybse Open Server libraries
**
** ARGUMENTS   : OpenServer        Open Server name
**
** RETURNS     : TRUE if successful, FALSE otherwise
**
******************************************************************************/
BOOL sybinit(char OpenServer[])
{

	CS_RETCODE rc;

	printf("calling cs_ctx_alloc ...\n");
#if	LOGGER_PLATFORM_IS_WIN32
	rc = cs_ctx_alloc(CS_VERSION_110,&Gctx_ptr);
#else
	rc = cs_ctx_alloc(CS_VERSION_100,&Gctx_ptr);
#endif
	if(rc!=CS_SUCCEED) { printf("cs_ctx_alloc failed\n"); return 1; }

	printf("calling ct_init ...\n");
	rc = ct_init(Gctx_ptr,CS_VERSION_100);
	if(rc!=CS_SUCCEED) { printf("ct_init failed\n"); return 1; }

	/* install CS callback */
	printf("calling cs_config(...,CS_MESSAGE_CB,...) ...\n");
	rc = cs_config(Gctx_ptr,CS_SET,CS_MESSAGE_CB,logger_test_cs_callback,
					CS_UNUSED,(CS_INT*)NULL);
	if(rc!=CS_SUCCEED) { printf("cs_config failed\n"); return 1; }
					
	/* install CT callback*/
	printf("calling cs_config(...,CS_CLIENTMSG_CB,...) ...\n");
	rc = ct_callback(Gctx_ptr,(CS_CONNECTION*)NULL,CS_SET,
						CS_CLIENTMSG_CB,logger_test_ct_callback);
	if(rc!=CS_SUCCEED) { printf("ct_callback failed\n"); return 1; }

	/* install SRV callback*/
	printf("calling cs_config(...,CS_SERVERMSG_CB,...) ...\n");
	rc = ct_callback(Gctx_ptr,(CS_CONNECTION*)NULL,CS_SET,
						CS_SERVERMSG_CB,logger_test_srv_callback);
	if(rc!=CS_SUCCEED) { printf("ct_callback failed\n"); return 1; }

	printf("calling srv_version ...\n");
#if	LOGGER_PLATFORM_IS_WIN32
	rc = srv_version(Gctx_ptr,CS_VERSION_110);
#else
	rc = srv_version(Gctx_ptr,CS_VERSION_100);
#endif
	if(rc!=CS_SUCCEED) { printf("srv_version failed\n"); return 1; }

	printf("calling srv_props ...\n");
	rc = srv_props(Gctx_ptr,CS_SET, SRV_S_LOGFILE,(CS_VOID*)SYBASE_LOG_FILE,
					strlen(SYBASE_LOG_FILE),(CS_INT*)NULL);
	if(rc!=CS_SUCCEED) { printf("srv_props failed\n"); return 1; }

	printf("calling srv_init ...\n");
	(void)srv_init((SRV_CONFIG*)NULL,OpenServer,strlen(OpenServer));

	return 0;
}


/**********************
** CALLBACK HANDLERS **
**********************/

CS_RETCODE CS_PUBLIC logger_test_cs_callback
(
	CS_CONTEXT   *ContextPtr,
	CS_CLIENTMSG *MsgPtr
)
{
	/* format and log the error message string */
	printf("Client/Server Library: error %ld, severity %ld, origin %ld, layer %ld (%s)",
			CS_NUMBER(MsgPtr->msgnumber),CS_SEVERITY(MsgPtr->msgnumber),
			CS_ORIGIN(MsgPtr->msgnumber),CS_LAYER(MsgPtr->msgnumber),MsgPtr->msgstring);
	
	return CS_SUCCEED;
}

CS_RETCODE CS_PUBLIC logger_test_ct_callback
(
	CS_CONTEXT    *ContextPtr,
	CS_CONNECTION *ConnectionPtr,
	CS_CLIENTMSG  *MsgPtr
)
{

	/* log the message as appropriate */
	if (MsgPtr->osnumber == 0)
	{
		/* this is an Open Client informational or error message */
		if ((MsgPtr->severity == CS_SV_INFORM) || (MsgPtr->msgnumber == 0))
		{
			/* this is an Open Client informational message */
			printf("Client-Library: error %ld severity %ld (%s)",
						MsgPtr->msgnumber,MsgPtr->severity,MsgPtr->msgstring);
		}
		else
		{
			/* this is an Open Client error message */
			printf("Client-Library: error %ld severity %ld (%s)",
				MsgPtr->msgnumber,MsgPtr->severity,MsgPtr->msgstring);
		}
	}
	else
	{
		/* this is an operating system error message */
		printf("Operating System: error %ld (%s)",MsgPtr->osnumber,MsgPtr->osstring);
	}

	return CS_SUCCEED;
}

CS_RETCODE CS_PUBLIC logger_test_srv_callback
(
	CS_CONTEXT    *ContextPtr,
	CS_CONNECTION *ConnectionPtr,
	CS_SERVERMSG  *MsgPtr
)
{
	
	static char MsgBuffer[5000];

	sprintf(MsgBuffer,"Server message number: %ld, Severity %ld, State %ld, Line %ld ",
		MsgPtr->msgnumber,MsgPtr->severity,MsgPtr->state,MsgPtr->line);
	
	if (MsgPtr->svrnlen > 0)
	{
		strcat(MsgBuffer,"Server ");
		strcat(MsgBuffer,MsgPtr->svrname);
		strcat(MsgBuffer," ");
	}
	
	if (MsgPtr->proclen > 0)
	{
		strcat(MsgBuffer,"Procedure ");
		strcat(MsgBuffer,MsgPtr->proc);
		strcat(MsgBuffer," ");
	}

	strcat(MsgBuffer,"Message: ");
	strcat(MsgBuffer,MsgPtr->text);

	printf(MsgBuffer);

	return CS_SUCCEED;
}

#endif	// LOGGER_BUILD_WITH_SYBASE_HEADERS
