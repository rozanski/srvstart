#!/bin/bash

software_root=/mnt/d/Home/Software/srvstart.v110
home_bin=/mnt/d/Home/bin
export NT_home='D:\Home\Software\srvstart.v110'

mode=cmd
flags='-c D:\Home\Software\srvstart.v110\test\test_ctrl.ctrl'

# -------------------------

echo 'Config [D|R]?'
read reply
# if [ "$reply" == R ]; then Config=Release; else Config=Debug; fi
if [ "$reply" == D ]; then Config=Debug; else Config=Release; fi

# -------------------------

export PATH=$software_root/exe/$Config:$software_root/dll/$Config:$home_bin:$PATH

# -------------------------

echo "Test number?"
read test_number

svc=TEST_SVC_${test_number}

# -------------------------

# echo PATH is $PATH

echo
echo '------------------------------------------'
echo srvstart.exe $mode $svc $flags "$cmd" $parms
echo '------------------------------------------'
echo

srvstart.exe $mode $svc $flags

