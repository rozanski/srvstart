#!/bin/bash

software_root_unix=/mnt/d/Home/Software/srvstart.v110
software_root_dos="`cygpath -w ${software_root_unix}`"

ctrlfile=$software_root_unix/test/test_install.ctrl

# -------------------------

logfile="${software_root_dos}\test\test_install.log"
> ${logfile}

# -------------------------

function parms_600()
{
	option=install
	parameters=''
}

# -------------------------

function parms_601()
{
	option=install
	svc=TEST_SVC
	parameters=''
}

# -------------------------

function parms_602()
{
	option=install
	svc=TEST_SVC
	parameters='-q ZZZ'
}

# -------------------------

function parms_603()
{
	option=install
	svc=TEST_SVC
	parameters='-c C:\configfile'
}

# -------------------------

function parms_604()
{
	option=install
	svc=TEST_SVC2
	parameters="-c $software_root_dos\\test\test_install.ctrl"
}

# -------------------------

function parms_605()
{
	option=remove
	svc=TEST_SVC2
}

# -------------------------

function parms_606()
{
	option=install_desktop
	svc=TEST_SVC2
	parameters="-c $software_root_dos\\test\test_install.ctrl"
}

# -------------------------

function parms_1001()
{
	program=/mnt/d/home/bin/srvstart.exe
	echo " (using Home/bin executable for this test)"
	option=remove
	svc=WASHER
}

# -------------------------

function parms_1002()
{
	program=/mnt/d/home/bin/srvstart.exe
	echo " (using Home/bin executable for this test)"
	option=install_desktop
	svc=WASHER
	parameters="-c d:\\home\\system\\etc\\srvstart.ctrl"
}

# -------------------------

function parms_1003()
{
	program=/mnt/d/home/bin/srvstart.exe
	echo " (using Home/bin executable for this test)"
	option=remove
	svc=URL_ORGANIZER
}

# -------------------------

function parms_1004()
{
	program=/mnt/d/home/bin/srvstart.exe
	echo " (using Home/bin executable for this test)"
	option=install_desktop
	svc=URL_ORGANIZER
	parameters="-c d:\\home\\system\\etc\\srvstart.ctrl"
}

# -------------------------

echo 'Config [D|R]?'
read reply
if [ "$reply" == R ]; then Config=Release; else Config=Debug; fi
# if [ "$reply" == D ]; then Config=Debug; else Config=Release; fi

# -------------------------

export PATH=$software_root_unix/exe/$Config:$software_root_unix/dll/$Config:$home_bin:$PATH
program=srvstart.exe
type -a $program

# -------------------------

echo "Test number?"
read test_number

option=''
svc=''
parameters=''

parms_${test_number}

# -------------------------

command="$program $option $svc $parameters"

echo '------------------------------------------'
echo About to run command $command
echo '------------------------------------------'
echo

$command

