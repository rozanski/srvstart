#!/bin/bash

svc=TEST_SVC

software_root_unix=/mnt/d/Home/Software/srvstart
software_root_dos="`cygpath -w ${software_root_unix}`"

ctrlfile=$software_root_unix/Debug/TEST_SVC.ctrl
service_cmd="${software_root_dos}\Debug\testsvc.bat"

# -------------------------

logfile="${software_root_dos}\Debug\TEST_SVC.log"
> ${logfile}

# -------------------------

function ctrl_100()
{
	:
}

# -------------------------

function ctrl_101()
{
	echo lib=MYLIB
	echo path=MYPATH
	echo priority=high
	echo sybase=MYSYB
}

# -------------------------

function ctrl_102()
{
	echo lib=MYLIB
	echo startup_dir='D:\Home'
	echo startup_delay=10
	echo wait_time=100
}

# -------------------------

function ctrl_103()
{
	echo lib=MYLIB
	echo startup_dir='D:\Home'
	echo priority=high
	echo wait="${software_root_dos}\Debug\wait_20.bat"
}

# -------------------------

function ctrl_200()
{
	echo lib=MYLIB
	echo startup_dir='D:\Home'
	echo auto_restart=y
}

# -------------------------

function ctrl_201()
{
	echo lib=MYLIB
	echo startup_dir='D:\Home'
	echo auto_restart=y
	echo restart_interval=8
}

# -------------------------

function ctrl_202()
{
	echo lib=MYLIB
	echo startup_dir='D:\Home'
	echo startup="${software_root_dos}\Debug\testsvc_kill.bat"
}

# -------------------------

function ctrl_203()
{
	echo lib=MYLIB
	echo startup_dir='D:\Home'
	echo startup="${software_root_dos}\Debug\testsvc_kill.bat"
	echo shutdown="${software_root_dos}\Debug\kill.bat"
}

# -------------------------

echo 'Config [D|R]?'
read reply
if [ "$reply" == R ]; then Config=Release; else Config=Debug; fi
# if [ "$reply" == D ]; then Config=Debug; else Config=Release; fi

echo Copying executables ...
cp -f ${software_root_unix}/exe/${Config}/srvstart.exe /mnt/d/home/bin
cp -f ${software_root_unix}/dll/${Config}/srvstart.dll /mnt/d/home/bin
echo Complete.

# -------------------------

echo "Test number?"
read test_number

# -------------------------

echo Creating control file ...

echo '# control file for test ' ${test_number} > $ctrlfile
echo "# `date`"                                >> $ctrlfile
echo ''                                        >> $ctrlfile

echo '['$svc']'                                >> $ctrlfile
echo startup="$service_cmd"                    >> $ctrlfile

echo "debug_out=${logfile}"                    >> $ctrlfile

ctrl_${test_number}                            >> $ctrlfile

echo ''                                        >> $ctrlfile

echo '# end of control file'                   >> $ctrlfile

echo Complete.

# -------------------------

echo '------------------------------------------'
echo Starting service $svc test $test_number ...
echo '------------------------------------------'
echo

date
net.exe start $svc
date

# -------------------------

echo
echo Waiting for service to stop ...
echo

while [ "`net.exe start | grep Rozanski`" ]
do
   if [ $? != 0 ]; then break; fi
   echo still running at `date` ...
   sleep 5
done

echo
echo Service has stopped.

