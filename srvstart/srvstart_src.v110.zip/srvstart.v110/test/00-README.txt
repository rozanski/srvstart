Run these scripts using Cygnus or some other Unix shell environment on Windows NT.

- run test_cmd.bash to test command mode
- run test_ctrl.bash to test command mode + config file
- run test_svc.bash to test service mode operations (with control files)

