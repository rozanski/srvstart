#!/bin/bash

software_root=/mnt/d/Home/Software/srvstart.v110
home_bin=/mnt/d/Home/bin
svc=TEST_SVC
export NT_home='D:\Home\Software\srvstart.v110'

# -------------------------

function parms_100()
{
	:
}

function parms_101()
{
	mode='-h'
}

function parms_102()
{
	mode=zzz
	cmd='\test\testcmd.bat'
}

function parms_103()
{
	mode=cmd
	cmd='nosuchcommand'
}

function parms_104()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
}

function parms_105()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	parms='a b c d'
}

# -------------------------

function parms_200()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	flags='-w'
}

function parms_201()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	flags='-w -m'
}

function parms_202()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	flags='-w -m -x normal'
}

function parms_203()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	flags='-w -m -x high'
}

function parms_204()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	flags='-w -m -x badpri'
}

# -------------------------

function parms_300()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	flags='-e myvar=myvalue'
}

function parms_301()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat %systemroot%'
	flags='-e myvar=myvalue -enewvar=newvalue_%systemroot%_xxx'
}

function parms_302()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	flags='-ssybdir'
}

function parms_303()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	flags='-ssybdir -l libdir '
}

function parms_304()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	flags='-l libdir -ssybdir'
}

function parms_305()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	flags='-p mypath -l libdir -ssybdir'
}

function parms_306()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	flags='-q sybdir'
}

# -------------------------

function parms_400()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	flags='-d 0'
}

function parms_401()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	flags='-d 1'
}

function parms_402()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	flags='-d 2'
}

function parms_403()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	flags='-o LOG'
}

function parms_404()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	flags='-o test_cmd.log'
}

# -------------------------

function parms_500()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	parms='{parm1:}'
}

# -------------------------

function parms_501()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	parms='{parm1:p1default}'
}

# -------------------------

function parms_502()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	parms='{-parm1:}'
}

# -------------------------

function parms_503()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	parms='{-parm1:p1def}'
}

# -------------------------

function parms_504()
{
	mode=cmd
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	parms='{-parm1:p1def} p2 {parm3:p3def} p4 {parm5:}'
}

# -------------------------

function parms_600()
{
	mode=any
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
}

function parms_601()
{
	mode=any
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	flags='-w'
}

function parms_602()
{
	mode=svc
	cmd='D:\Home\Software\srvstart.v110\test\testcmd.bat'
	flags='-w'
}

# -------------------------

echo 'Config [D|R]?'
read reply
# if [ "$reply" == R ]; then Config=Release; else Config=Debug; fi
if [ "$reply" == D ]; then Config=Debug; else Config=Release; fi

# -------------------------

export PATH=$software_root/exe/$Config:$software_root/dll/$Config:$home_bin:$PATH
mode=''
flags=''
cmd=''
parms=''

# -------------------------

echo "Test number?"
read test_number

parms_${test_number}

# -------------------------

# echo PATH is $PATH

echo
echo '------------------------------------------'
echo srvstart.v110.exe $mode $svc $flags "$cmd" $parms
echo '------------------------------------------'
echo

srvstart.exe $mode $svc $flags "$cmd" $parms
# $software_root/exe/$Config/srvstart.exe $mode $svc $flags "$cmd" $parms

