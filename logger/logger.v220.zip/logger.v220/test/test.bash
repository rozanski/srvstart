#!/bin/bash.exe

logger_dir=/mnt/d/home/Author/logger.v210
sybase_dir=/mnt/d/software/sybase
# config=Release_Sybase
config=Release

export PATH=${logger_dir}/dll/${config}:${sybase_dir}/dll:/bin:/usr/bin:/mnt/c/winnt:/mnt/winnt/system32

echo "PATH is $PATH"

cd ${logger_dir}/test/${config}

./test.exe

